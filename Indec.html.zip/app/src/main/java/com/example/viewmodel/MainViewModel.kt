package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.TransactionItem
import com.example.data.local.UserProfile
import com.example.data.repository.TransactionRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class MonthSummary(
    val monthKey: String, // "2026-10"
    val monthDisplay: String, // "October 2026"
    val totalIncome: Double,
    val totalExpense: Double,
    val netSavings: Double,
    val categoryBreakdown: Map<String, Double>
)

data class DaySummary(
    val dateKey: String, // "2026-10-10"
    val dayName: String, // "Sat"
    val totalExpense: Double
)

data class YearSummary(
    val year: Int,
    val totalIncome: Double,
    val totalExpense: Double,
    val netSavings: Double,
    val monthlyData: List<MonthSummary>
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = TransactionRepository(database.appDao())

    val activeUser: StateFlow<UserProfile?> = repository.activeUser
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allUsers: StateFlow<List<UserProfile>> = repository.allUsers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val transactions: StateFlow<List<TransactionItem>> = activeUser
        .flatMapLatest { user ->
            if (user != null) repository.getAllTransactions(user.id)
            else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Feedback and errors
    private val _uiMessage = MutableStateFlow<String?>(null)
    val uiMessage = _uiMessage.asStateFlow()

    fun clearUiMessage() {
        _uiMessage.value = null
    }

    fun showMessage(msg: String) {
        _uiMessage.value = msg
    }

    // Auth actions
    fun register(
        fullName: String,
        houseName: String,
        emailOrPhone: String,
        password: String,
        currencySymbol: String,
        monthlyBudget: Double,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            if (fullName.isBlank()) {
                _uiMessage.value = "Apna naam zaroor darj karein!"
                return@launch
            }
            if (emailOrPhone.isBlank() || password.isBlank()) {
                _uiMessage.value = "Email/Phone aur Password zaroori hain!"
                return@launch
            }
            val res = repository.registerUser(
                fullName.trim(),
                houseName.ifBlank { "Mera Ghar" }.trim(),
                emailOrPhone.trim(),
                password.trim(),
                currencySymbol,
                monthlyBudget
            )
            res.onSuccess {
                _uiMessage.value = "Mubarak ho! Account kamyabi se ban gaya."
                onSuccess()
            }.onFailure { err ->
                _uiMessage.value = err.message ?: "Account banane me masla hua!"
            }
        }
    }

    fun login(emailOrPhone: String, password: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            if (emailOrPhone.isBlank() || password.isBlank()) {
                _uiMessage.value = "Email/Phone aur Password darj karein!"
                return@launch
            }
            val res = repository.loginUser(emailOrPhone.trim(), password.trim())
            res.onSuccess {
                _uiMessage.value = "Khush Aamdeed! Login kamyab."
                onSuccess()
            }.onFailure { err ->
                _uiMessage.value = err.message ?: "Login ghalat hai!"
            }
        }
    }

    fun switchUser(userId: Int) {
        viewModelScope.launch {
            repository.switchActiveUser(userId)
            _uiMessage.value = "Account tabdeel ho gaya."
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
            _uiMessage.value = "Log out ho gaye."
        }
    }

    fun updateProfile(profile: UserProfile) {
        viewModelScope.launch {
            repository.updateProfile(profile)
            _uiMessage.value = "Profile update ho gayi!"
        }
    }

    // CRUD Transactions
    fun addExpense(
        amount: Double,
        category: String,
        title: String,
        date: String,
        paymentMode: String,
        note: String
    ) {
        val user = activeUser.value ?: return
        viewModelScope.launch {
            val item = TransactionItem(
                userId = user.id,
                type = "EXPENSE",
                amount = amount,
                category = category,
                title = title.ifBlank { category },
                date = date,
                paymentMode = paymentMode,
                note = note
            )
            repository.insertTransaction(item)
            _uiMessage.value = "Daily Kharcha shamil kar diya gaya!"
        }
    }

    fun updateExpense(item: TransactionItem) {
        viewModelScope.launch {
            repository.updateTransaction(item.copy(type = "EXPENSE"))
            _uiMessage.value = "Kharcha update ho gaya!"
        }
    }

    fun deleteTransaction(item: TransactionItem) {
        viewModelScope.launch {
            repository.deleteTransaction(item)
            _uiMessage.value = "Record delete kar diya gaya."
        }
    }

    fun addIncome(
        amount: Double,
        category: String,
        title: String,
        date: String,
        paymentMode: String,
        note: String
    ) {
        val user = activeUser.value ?: return
        viewModelScope.launch {
            val item = TransactionItem(
                userId = user.id,
                type = "INCOME",
                amount = amount,
                category = category,
                title = title.ifBlank { "Ghar Se Mile: $category" },
                date = date,
                paymentMode = paymentMode,
                note = note
            )
            repository.insertTransaction(item)
            _uiMessage.value = "Ghar Se Mile Paise darj ho gaye!"
        }
    }

    fun updateIncome(item: TransactionItem) {
        viewModelScope.launch {
            repository.updateTransaction(item.copy(type = "INCOME"))
            _uiMessage.value = "Raqam ka record update ho gaya!"
        }
    }

    // Helper functions for dates
    companion object {
        fun getTodayString(): String {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            return sdf.format(Date())
        }

        fun getCurrentMonthKey(): String {
            val sdf = SimpleDateFormat("yyyy-MM", Locale.getDefault())
            return sdf.format(Date())
        }

        fun formatAmount(amount: Double, symbol: String = "₨"): String {
            return String.format(Locale.getDefault(), "%s %,.0f", symbol, amount)
        }
    }
}
