package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Coffee
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.LocalMall
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

data class CategoryMeta(
    val id: String,
    val nameEn: String,
    val nameUrdu: String,
    val icon: ImageVector,
    val color: Color
)

object CategoryConstants {
    val EXPENSE_CATEGORIES = listOf(
        CategoryMeta("Rashan (Groceries)", "Groceries / Rashan", "راشن اور سودا سلف", Icons.Default.ShoppingCart, Color(0xFFE65100)),
        CategoryMeta("Sabzi & Fruit", "Vegetables & Fruit", "سبزی اور پھل", Icons.Default.Restaurant, Color(0xFF2E7D32)),
        CategoryMeta("Doodh (Milk)", "Milk & Dairy", "دودھ اور دہی", Icons.Default.LocalMall, Color(0xFF0288D1)),
        CategoryMeta("Bijli & Gas Bills", "Electricity & Gas Bills", "بجلی اور گیس کے بل", Icons.Default.ElectricBolt, Color(0xFFF57F17)),
        CategoryMeta("Kiraya (Rent)", "House Rent", "گھر کا کرایہ", Icons.Default.Home, Color(0xFF6A1B9A)),
        CategoryMeta("Petrol & Safar", "Fuel & Transport", "پیٹرول اور سفر", Icons.Default.DirectionsCar, Color(0xFF00838F)),
        CategoryMeta("Dawa & Doctor", "Medical & Pharmacy", "دوا اور علاج", Icons.Default.LocalHospital, Color(0xFFC2185B)),
        CategoryMeta("Bachon Ki Parhai", "Kids Education & Fees", "بچوں کی فیس اور کتابیں", Icons.Default.School, Color(0xFF283593)),
        CategoryMeta("Chai & Khana", "Breakfast & Dining", "چائے، ناشتہ اور کھانا", Icons.Default.Coffee, Color(0xFF795548)),
        CategoryMeta("Ghar Ki Marammat", "Home Repairs & Maint", "گھر کی مرمت", Icons.Default.Build, Color(0xFF455A64)),
        CategoryMeta("Mobile & Internet", "Mobile, Net & Cable", "موبائل اور انٹرنیٹ", Icons.Default.PhoneAndroid, Color(0xFF009688)),
        CategoryMeta("Other Misc", "Other Expenses", "دیگر متفرق خرچے", Icons.Default.Payments, Color(0xFF546E7A))
    )

    val INCOME_CATEGORIES = listOf(
        CategoryMeta("Abba Jaan", "Father (Abba Jaan)", "والد صاحب (ابو)", Icons.Default.VolunteerActivism, Color(0xFF1B5E20)),
        CategoryMeta("Ammi", "Mother (Ammi)", "والدہ محترمہ (امی)", Icons.Default.VolunteerActivism, Color(0xFF2E7D32)),
        CategoryMeta("Bhai / Sister", "Brother / Sibling", "بھائی / بہن کی طرف سے", Icons.Default.Payments, Color(0xFF00796B)),
        CategoryMeta("Ghar Ka Monthly Budget", "Monthly House Budget", "گھر کا ماہانہ بجٹ", Icons.Default.AccountBalance, Color(0xFF0D47A1)),
        CategoryMeta("Salary / Kamai", "Salary / Earnings", "تنخواہ اور کمائی", Icons.Default.Wallet, Color(0xFF1565C0)),
        CategoryMeta("Pocket Money", "Allowance / Pocket Money", "خرچی / جیب خرچ", Icons.Default.Payments, Color(0xFF00897B)),
        CategoryMeta("Other Gift", "Gifts / Relatives", "تحفہ اور دیگر رقوم", Icons.Default.VolunteerActivism, Color(0xFF6A1B9A))
    )

    val PAYMENT_MODES = listOf("Cash", "Bank Transfer", "EasyPaisa", "JazzCash")

    fun getCategoryMeta(name: String, isIncome: Boolean): CategoryMeta {
        val list = if (isIncome) INCOME_CATEGORIES else EXPENSE_CATEGORIES
        return list.find { it.id.equals(name, ignoreCase = true) || it.nameEn.contains(name, ignoreCase = true) }
            ?: (if (isIncome) INCOME_CATEGORIES.last() else EXPENSE_CATEGORIES.last())
    }
}
