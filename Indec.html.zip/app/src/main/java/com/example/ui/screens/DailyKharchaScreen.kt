package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.TransactionItem
import com.example.data.local.UserProfile
import com.example.model.CategoryConstants
import com.example.ui.components.TransactionRowItem
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.TextMuted
import com.example.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun DailyKharchaScreen(
    user: UserProfile?,
    transactions: List<TransactionItem>,
    onAddExpense: () -> Unit,
    onEditExpense: (TransactionItem) -> Unit,
    onDeleteExpense: (TransactionItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val currency = user?.currencySymbol ?: "₨"
    val todayStr = MainViewModel.getTodayString()

    // Calculate yesterday's date
    val cal = Calendar.getInstance()
    cal.add(Calendar.DAY_OF_YEAR, -1)
    val yesterdayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time)

    // Calculate 7 days ago date
    cal.time = Date()
    cal.add(Calendar.DAY_OF_YEAR, -7)
    val sevenDaysAgoStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time)

    val currentMonthPrefix = MainViewModel.getCurrentMonthKey()

    var selectedPeriod by remember { mutableStateOf("TODAY") } // "TODAY", "YESTERDAY", "WEEK", "MONTH", "ALL"
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    val allExpenses = transactions.filter { it.type == "EXPENSE" }

    val filteredExpenses = allExpenses.filter { item ->
        val matchesPeriod = when (selectedPeriod) {
            "TODAY" -> item.date == todayStr
            "YESTERDAY" -> item.date == yesterdayStr
            "WEEK" -> item.date >= sevenDaysAgoStr
            "MONTH" -> item.date.startsWith(currentMonthPrefix)
            else -> true
        }
        val matchesCategory = if (selectedCategory == null) true else item.category == selectedCategory
        val matchesSearch = if (searchQuery.isBlank()) true else {
            item.title.contains(searchQuery, ignoreCase = true) ||
                    item.category.contains(searchQuery, ignoreCase = true) ||
                    item.note.contains(searchQuery, ignoreCase = true)
        }
        matchesPeriod && matchesCategory && matchesSearch
    }

    val totalPeriodExpense = filteredExpenses.sumOf { it.amount }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("daily_kharcha_screen"),
            contentPadding = PaddingValues(bottom = 96.dp)
        ) {
            // Screen Header & Banner
            item {
                Surface(
                    color = ExpenseRed,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 20.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(
                                    text = "Daily Kharcha (روزانہ خرچہ)",
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Ghar ke roz marra ke tamam ikhrajat ka record",
                                    fontSize = 12.sp,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ShoppingCart,
                                    contentDescription = "Expense",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Period Total Card inside Banner
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    val periodTitle = when (selectedPeriod) {
                                        "TODAY" -> "Aaj Ka Kharcha (Today)"
                                        "YESTERDAY" -> "Kal Ka Kharcha (Yesterday)"
                                        "WEEK" -> "Pichle 7 Din Ka Kharcha"
                                        "MONTH" -> "Is Mahine Ka Kharcha"
                                        else -> "Kul Kharcha (All Time)"
                                    }
                                    Text(
                                        text = periodTitle,
                                        fontSize = 12.sp,
                                        color = TextMuted
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = MainViewModel.formatAmount(totalPeriodExpense, currency),
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = ExpenseRed
                                    )
                                }
                                Surface(
                                    color = ExpenseRed.copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = "${filteredExpenses.size} Kharchay",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = ExpenseRed,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Period Filter Chips
            item {
                Column(modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)) {
                    Text(
                        text = "Tareekh / Muddat Muntakhib Karein:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            FilterChip(
                                selected = selectedPeriod == "TODAY",
                                onClick = { selectedPeriod = "TODAY" },
                                label = { Text("Aaj (Today)") },
                                modifier = Modifier.testTag("period_today")
                            )
                        }
                        item {
                            FilterChip(
                                selected = selectedPeriod == "YESTERDAY",
                                onClick = { selectedPeriod = "YESTERDAY" },
                                label = { Text("Kal (Yesterday)") },
                                modifier = Modifier.testTag("period_yesterday")
                            )
                        }
                        item {
                            FilterChip(
                                selected = selectedPeriod == "WEEK",
                                onClick = { selectedPeriod = "WEEK" },
                                label = { Text("Is Haftay (7 Days)") },
                                modifier = Modifier.testTag("period_week")
                            )
                        }
                        item {
                            FilterChip(
                                selected = selectedPeriod == "MONTH",
                                onClick = { selectedPeriod = "MONTH" },
                                label = { Text("Is Mahine (Month)") },
                                modifier = Modifier.testTag("period_month")
                            )
                        }
                        item {
                            FilterChip(
                                selected = selectedPeriod == "ALL",
                                onClick = { selectedPeriod = "ALL" },
                                label = { Text("Sab (All)") },
                                modifier = Modifier.testTag("period_all")
                            )
                        }
                    }
                }
            }

            // Category Filter
            item {
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            FilterChip(
                                selected = selectedCategory == null,
                                onClick = { selectedCategory = null },
                                label = { Text("Tamam Categories") }
                            )
                        }
                        items(CategoryConstants.EXPENSE_CATEGORIES) { cat ->
                            FilterChip(
                                selected = selectedCategory == cat.id,
                                onClick = {
                                    selectedCategory = if (selectedCategory == cat.id) null else cat.id
                                },
                                label = { Text(cat.nameEn) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = cat.icon,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            )
                        }
                    }
                }
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Kharcha search karein (rashan, bill, petrol)...") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = TextMuted)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .testTag("expense_search_field"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    singleLine = true
                )
            }

            // Expense Items
            if (filteredExpenses.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Is muddat me koi kharcha darj nahi!",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp,
                                color = TextMuted
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Neeche diye gaye button se naya kharcha add karein.",
                                fontSize = 12.sp,
                                color = TextMuted
                            )
                        }
                    }
                }
            } else {
                items(filteredExpenses, key = { it.id }) { item ->
                    TransactionRowItem(
                        item = item,
                        currencySymbol = currency,
                        onEdit = { onEditExpense(item) },
                        onDelete = { onDeleteExpense(item) },
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp)
                    )
                }
            }
        }

        // Floating Action Button
        ExtendedFloatingActionButton(
            onClick = onAddExpense,
            icon = { Icon(imageVector = Icons.Default.Add, contentDescription = "Add Expense") },
            text = { Text("Kharcha Add Karein", fontWeight = FontWeight.Bold) },
            containerColor = ExpenseRed,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 90.dp, end = 20.dp)
                .testTag("daily_kharcha_fab")
        )
    }
}
