package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.TransactionItem
import com.example.data.local.UserProfile
import com.example.model.CategoryConstants
import com.example.ui.components.SimpleBarChart
import com.example.ui.components.SummaryStatCard
import com.example.ui.components.TransactionRowItem
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BalanceBlue
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.TextMuted
import com.example.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun ReportsScreen(
    user: UserProfile?,
    transactions: List<TransactionItem>,
    modifier: Modifier = Modifier
) {
    val currency = user?.currencySymbol ?: "₨"
    var selectedReportTab by remember { mutableIntStateOf(0) } // 0: Weekly, 1: Monthly, 2: Yearly

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("reports_screen")
    ) {
        // Top App Bar / Title
        Surface(
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Text(
                    text = "Ghar Ke Hisaab Kitab Reports",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "ہفتہ وار، ماہانہ اور سالانہ مالیاتی رپورٹ",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }
        }

        // Primary Tabs
        TabRow(
            selectedTabIndex = selectedReportTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary
        ) {
            Tab(
                selected = selectedReportTab == 0,
                onClick = { selectedReportTab = 0 },
                text = { Text("Weekly Report\n(ہفتہ وار)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.testTag("tab_weekly_report")
            )
            Tab(
                selected = selectedReportTab == 1,
                onClick = { selectedReportTab = 1 },
                text = { Text("Monthly Report\n(ماہانہ)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.testTag("tab_monthly_report")
            )
            Tab(
                selected = selectedReportTab == 2,
                onClick = { selectedReportTab = 2 },
                text = { Text("Yearly Report\n(سالانہ)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.ShowChart, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.testTag("tab_yearly_report")
            )
        }

        when (selectedReportTab) {
            0 -> WeeklyReportView(user = user, transactions = transactions, currency = currency)
            1 -> MonthlyReportView(user = user, transactions = transactions, currency = currency)
            2 -> YearlyReportView(user = user, transactions = transactions, currency = currency)
        }
    }
}

@Composable
private fun WeeklyReportView(
    user: UserProfile?,
    transactions: List<TransactionItem>,
    currency: String
) {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val dayFormat = SimpleDateFormat("EEE", Locale.getDefault())

    // Generate last 7 days list
    val last7Days = remember {
        (6 downTo 0).map { daysAgo ->
            val c = Calendar.getInstance()
            c.add(Calendar.DAY_OF_YEAR, -daysAgo)
            Pair(sdf.format(c.time), dayFormat.format(c.time))
        }
    }

    val startDate = last7Days.first().first
    val endDate = last7Days.last().first

    val weekExpenses = transactions.filter {
        it.type == "EXPENSE" && it.date in startDate..endDate
    }

    val totalWeeklyKharcha = weekExpenses.sumOf { it.amount }
    val avgDailyKharcha = totalWeeklyKharcha / 7.0

    // Chart data for 7 days
    val chartData = last7Days.map { (dateKey, dayName) ->
        val sum = weekExpenses.filter { it.date == dateKey }.sumOf { it.amount }
        Pair(dayName, sum)
    }

    val maxDay = chartData.maxByOrNull { it.second }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("weekly_report_content"),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp)
    ) {
        // Summary Header Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Poore Haftay Ka Total Kharcha:",
                                fontSize = 13.sp,
                                color = TextMuted
                            )
                            Text(
                                text = "پچھلے 7 دن کا کل خرچہ",
                                fontSize = 11.sp,
                                color = ExpenseRed,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = "$startDate ta $endDate",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = MainViewModel.formatAmount(totalWeeklyKharcha, currency),
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold,
                        color = ExpenseRed
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Rozana Ausat (Average): ${MainViewModel.formatAmount(avgDailyKharcha, currency)}",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                        if (maxDay != null && maxDay.second > 0) {
                            Text(
                                text = "Sab Se Ziada: ${maxDay.first}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = ExpenseRed
                            )
                        }
                    }
                }
            }
        }

        // Daily Breakdown Chart
        item {
            Spacer(modifier = Modifier.height(14.dp))
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Rozana Kharcha Chart (7 Din):",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    SimpleBarChart(
                        data = chartData,
                        currencySymbol = currency,
                        barColor = ExpenseRed
                    )
                }
            }
        }

        // List of transactions for the week
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Is Haftay Ke Kharchay (${weekExpenses.size}):",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        if (weekExpenses.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "Is haftay me koi kharcha nahi hua.", color = TextMuted)
                }
            }
        } else {
            items(weekExpenses, key = { it.id }) { item ->
                TransactionRowItem(
                    item = item,
                    currencySymbol = currency,
                    onEdit = {},
                    onDelete = {},
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun MonthlyReportView(
    user: UserProfile?,
    transactions: List<TransactionItem>,
    currency: String
) {
    // Generate distinct months present in data or current months
    val currentMonthKey = MainViewModel.getCurrentMonthKey()
    val availableMonths = remember(transactions) {
        val set = mutableSetOf(currentMonthKey)
        transactions.forEach {
            if (it.date.length >= 7) {
                set.add(it.date.substring(0, 7))
            }
        }
        set.sortedDescending()
    }

    var selectedMonth by remember { mutableStateOf(availableMonths.firstOrNull() ?: currentMonthKey) }

    val monthTransactions = transactions.filter { it.date.startsWith(selectedMonth) }
    val totalIncome = monthTransactions.filter { it.type == "INCOME" }.sumOf { it.amount }
    val totalExpense = monthTransactions.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val netSavings = totalIncome - totalExpense

    // Category distribution for expenses
    val expenseCategories = monthTransactions.filter { it.type == "EXPENSE" }
        .groupBy { it.category }
        .mapValues { entry -> entry.value.sumOf { it.amount } }
        .toList()
        .sortedByDescending { it.second }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("monthly_report_content"),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp)
    ) {
        // Month Selector Chips
        item {
            Text(
                text = "Mahina Muntakhib Karein (Select Month):",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(availableMonths) { mKey ->
                    FilterChip(
                        selected = selectedMonth == mKey,
                        onClick = { selectedMonth = mKey },
                        label = { Text(mKey) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Side-by-side Monthly Overview
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SummaryStatCard(
                    title = "Ghar Se Mile Paise",
                    titleUrdu = "آمدن",
                    amount = MainViewModel.formatAmount(totalIncome, currency),
                    icon = Icons.Default.ArrowDownward,
                    accentColor = IncomeGreen,
                    bgColor = MaterialTheme.colorScheme.surface,
                    subtext = "Total Received",
                    modifier = Modifier.weight(1f)
                )

                SummaryStatCard(
                    title = "Mahana Kharcha",
                    titleUrdu = "خرچہ",
                    amount = MainViewModel.formatAmount(totalExpense, currency),
                    icon = Icons.Default.ArrowUpward,
                    accentColor = ExpenseRed,
                    bgColor = MaterialTheme.colorScheme.surface,
                    subtext = "Total Spent",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Net Savings Banner
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (netSavings >= 0) IncomeGreen.copy(alpha = 0.12f) else ExpenseRed.copy(alpha = 0.12f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (netSavings >= 0) "Mubarak! Mahana Bachat (Savings):" else "Afsoos! Mahana Nuqsan (Deficit):",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (netSavings >= 0) IncomeGreen else ExpenseRed
                        )
                        Text(
                            text = MainViewModel.formatAmount(netSavings, currency),
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (netSavings >= 0) IncomeGreen else ExpenseRed
                        )
                    }
                    Icon(
                        imageVector = if (netSavings >= 0) Icons.Default.TrendingUp else Icons.Default.ArrowUpward,
                        contentDescription = null,
                        tint = if (netSavings >= 0) IncomeGreen else ExpenseRed,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }

        // Category Breakdown Header
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Kahan Kitna Kharcha Hua? (Category Breakdown):",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        if (expenseCategories.isEmpty()) {
            item {
                Text(
                    text = "Is mahine me koi kharcha darj nahi.",
                    color = TextMuted,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        } else {
            items(expenseCategories) { (cat, amount) ->
                val meta = CategoryConstants.getCategoryMeta(cat, false)
                val pct = if (totalExpense > 0) (amount / totalExpense).toFloat() else 0f
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(meta.color.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = meta.icon,
                                        contentDescription = null,
                                        tint = meta.color,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = meta.nameEn,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = meta.nameUrdu,
                                        fontSize = 11.sp,
                                        color = TextMuted
                                    )
                                }
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = MainViewModel.formatAmount(amount, currency),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ExpenseRed
                                )
                                Text(
                                    text = "${(pct * 100).toInt()}%",
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { pct },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = meta.color,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun YearlyReportView(
    user: UserProfile?,
    transactions: List<TransactionItem>,
    currency: String
) {
    val currentYear = Calendar.getInstance().get(Calendar.YEAR)
    var selectedYear by remember { mutableIntStateOf(currentYear) }

    val yearTransactions = transactions.filter {
        it.date.startsWith("$selectedYear")
    }

    val totalAnnualIncome = yearTransactions.filter { it.type == "INCOME" }.sumOf { it.amount }
    val totalAnnualExpense = yearTransactions.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val annualNetSavings = totalAnnualIncome - totalAnnualExpense

    // 12 months data
    val monthNames = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    val monthlyBarData = monthNames.mapIndexed { idx, name ->
        val monthStr = String.format(Locale.getDefault(), "%04d-%02d", selectedYear, idx + 1)
        val exp = yearTransactions.filter { it.type == "EXPENSE" && it.date.startsWith(monthStr) }.sumOf { it.amount }
        Pair(name, exp)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("yearly_report_content"),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp)
    ) {
        // Year Selector
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Saal Ka Hisaab ($selectedYear):",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(currentYear, currentYear - 1).forEach { yr ->
                        FilterChip(
                            selected = selectedYear == yr,
                            onClick = { selectedYear = yr },
                            label = { Text("$yr") }
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Annual Summary Stat Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SummaryStatCard(
                    title = "Kul Salana Income",
                    titleUrdu = "سالانہ رقم",
                    amount = MainViewModel.formatAmount(totalAnnualIncome, currency),
                    icon = Icons.Default.ArrowDownward,
                    accentColor = IncomeGreen,
                    bgColor = MaterialTheme.colorScheme.surface,
                    subtext = "Ghar Se Mile Paise",
                    modifier = Modifier.weight(1f)
                )

                SummaryStatCard(
                    title = "Kul Salana Kharcha",
                    titleUrdu = "سالانہ خرچہ",
                    amount = MainViewModel.formatAmount(totalAnnualExpense, currency),
                    icon = Icons.Default.ArrowUpward,
                    accentColor = ExpenseRed,
                    bgColor = MaterialTheme.colorScheme.surface,
                    subtext = "Total Annual Expenses",
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            SummaryStatCard(
                title = "Kul Salana Bachat / Savings",
                titleUrdu = "سال بھر کی بچت",
                amount = MainViewModel.formatAmount(annualNetSavings, currency),
                icon = Icons.Default.AccountBalanceWallet,
                accentColor = if (annualNetSavings >= 0) BalanceBlue else ExpenseRed,
                bgColor = MaterialTheme.colorScheme.surface,
                subtext = if (annualNetSavings >= 0) "MashaAllah! Positive Bachat" else "Overspent Deficit",
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 12 Months Bar Chart
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "12 Mahino Ka Kharcha (Month by Month Trend):",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    SimpleBarChart(
                        data = monthlyBarData,
                        currencySymbol = currency,
                        barColor = EmeraldPrimary
                    )
                }
            }
        }
    }
}
