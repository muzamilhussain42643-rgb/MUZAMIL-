package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.TransactionItem
import com.example.data.local.UserProfile
import com.example.ui.components.SummaryStatCard
import com.example.ui.components.TransactionRowItem
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BalanceBlue
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.TextMuted
import com.example.viewmodel.MainViewModel

@Composable
fun DashboardScreen(
    user: UserProfile?,
    transactions: List<TransactionItem>,
    onAddExpense: () -> Unit,
    onAddIncome: () -> Unit,
    onViewReports: () -> Unit,
    onEditTransaction: (TransactionItem) -> Unit,
    onDeleteTransaction: (TransactionItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val currency = user?.currencySymbol ?: "₨"
    val todayStr = MainViewModel.getTodayString()
    val currentMonthPrefix = MainViewModel.getCurrentMonthKey() // e.g. "2026-10"

    // Filtered calculations for current month
    val monthTransactions = transactions.filter { it.date.startsWith(currentMonthPrefix) }
    val totalIncomeMonth = monthTransactions.filter { it.type == "INCOME" }.sumOf { it.amount }
    val totalExpenseMonth = monthTransactions.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val netSavingsMonth = totalIncomeMonth - totalExpenseMonth
    val todayExpense = transactions.filter { it.type == "EXPENSE" && it.date == todayStr }.sumOf { it.amount }

    val monthlyTarget = user?.monthlyBudgetTarget ?: 60000.0
    val budgetProgress = if (monthlyTarget > 0) (totalExpenseMonth / monthlyTarget).toFloat().coerceIn(0f, 1f) else 0f

    var filterType by remember { mutableStateOf("ALL") } // "ALL", "EXPENSE", "INCOME"
    var searchQuery by remember { mutableStateOf("") }

    val filteredList = transactions.filter { item ->
        val matchesType = when (filterType) {
            "EXPENSE" -> item.type == "EXPENSE"
            "INCOME" -> item.type == "INCOME"
            else -> true
        }
        val matchesQuery = if (searchQuery.isBlank()) true else {
            item.title.contains(searchQuery, ignoreCase = true) ||
                    item.category.contains(searchQuery, ignoreCase = true) ||
                    item.note.contains(searchQuery, ignoreCase = true) ||
                    item.date.contains(searchQuery, ignoreCase = true)
        }
        matchesType && matchesQuery
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard_screen"),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // Hero Header with User Name & House Name
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                EmeraldDark,
                                EmeraldPrimary
                            )
                        )
                    )
                    .padding(horizontal = 20.dp, vertical = 24.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Assalam-o-Alaikum,",
                                fontSize = 14.sp,
                                color = Color.White.copy(alpha = 0.85f),
                                fontWeight = FontWeight.Normal
                            )
                            Text(
                                text = user?.fullName ?: "Muzamil Khan",
                                fontSize = 23.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        // House Name Badge
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White.copy(alpha = 0.18f),
                            modifier = Modifier.testTag("house_name_badge")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Home,
                                    contentDescription = "House",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = user?.houseName ?: "Khan House",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Date & Status Sub-row
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CalendarToday,
                                contentDescription = "Date",
                                tint = Color.White.copy(alpha = 0.8f),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Aaj: $todayStr (Mahana Hisaab)",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }

                        // Bachat Status Pill
                        val isPositive = netSavingsMonth >= 0
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isPositive) Color(0xFF10B981) else Color(0xFFEF4444)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isPositive) Icons.Default.TrendingUp else Icons.Default.Warning,
                                    contentDescription = "Status",
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isPositive) "Bachat Me Hai" else "Kharcha Ziada Hai",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4 Summary Cards Grid
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Ghar Se Mile Paise
                    SummaryStatCard(
                        title = "Ghar Se Mile Paise",
                        titleUrdu = "گھر سے رقم",
                        amount = MainViewModel.formatAmount(totalIncomeMonth, currency),
                        icon = Icons.Default.ArrowDownward,
                        accentColor = IncomeGreen,
                        bgColor = MaterialTheme.colorScheme.surface,
                        subtext = "Is Mahine Ka Total",
                        modifier = Modifier.weight(1f)
                    )

                    // Daily Kharcha (Mahana Expense)
                    SummaryStatCard(
                        title = "Mahana Kharcha",
                        titleUrdu = "کل ماہانہ خرچ",
                        amount = MainViewModel.formatAmount(totalExpenseMonth, currency),
                        icon = Icons.Default.ArrowUpward,
                        accentColor = ExpenseRed,
                        bgColor = MaterialTheme.colorScheme.surface,
                        subtext = "Rozana Kharchon Ka Total",
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Net Bachat
                    SummaryStatCard(
                        title = "Bachat / Balance",
                        titleUrdu = "بچت / باقی رقم",
                        amount = MainViewModel.formatAmount(netSavingsMonth, currency),
                        icon = Icons.Default.AccountBalanceWallet,
                        accentColor = if (netSavingsMonth >= 0) BalanceBlue else ExpenseRed,
                        bgColor = MaterialTheme.colorScheme.surface,
                        subtext = if (netSavingsMonth >= 0) "Mahana Bachat" else "Deficit / Nuqsan",
                        modifier = Modifier.weight(1f)
                    )

                    // Aaj Ka Kharcha
                    SummaryStatCard(
                        title = "Aaj Ka Kharcha",
                        titleUrdu = "آج کا خرچہ",
                        amount = MainViewModel.formatAmount(todayExpense, currency),
                        icon = Icons.Default.Today,
                        accentColor = AmberGold,
                        bgColor = MaterialTheme.colorScheme.surface,
                        subtext = "Today's Total",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Budget Target Bar
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Ghar Ka Monthly Budget Target:",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = MainViewModel.formatAmount(monthlyTarget, currency),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { budgetProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (budgetProgress > 0.85f) ExpenseRed else MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Kharch: ${MainViewModel.formatAmount(totalExpenseMonth, currency)} (${(budgetProgress * 100).toInt()}%)",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                        val remainingBudget = (monthlyTarget - totalExpenseMonth).coerceAtLeast(0.0)
                        Text(
                            text = "Baqi: ${MainViewModel.formatAmount(remainingBudget, currency)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (budgetProgress > 0.85f) ExpenseRed else IncomeGreen
                        )
                    }
                }
            }
        }

        // Quick Action Buttons
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "Quick Actions (فوری اندراج):",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onAddExpense,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dashboard_add_expense_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ Daily Kharcha", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onAddIncome,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dashboard_add_income_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = IncomeGreen),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ Ghar Se Mile", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Recent Activity Header & Filters
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Hisaab Kitab Record (تمام ریکارڈ):",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${filteredList.size} Entries",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Talaash karein (Search rashan, bills, abba se)...") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = TextMuted)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dashboard_search_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Filter Chips
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    FilterChip(
                        selected = filterType == "ALL",
                        onClick = { filterType = "ALL" },
                        label = { Text("Sab (تمام)") },
                        modifier = Modifier.testTag("filter_chip_all")
                    )
                    FilterChip(
                        selected = filterType == "EXPENSE",
                        onClick = { filterType = "EXPENSE" },
                        label = { Text("Rozana Kharcha") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ExpenseRed,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("filter_chip_expense")
                    )
                    FilterChip(
                        selected = filterType == "INCOME",
                        onClick = { filterType = "INCOME" },
                        label = { Text("Ghar Se Mile") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = IncomeGreen,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("filter_chip_income")
                    )
                }
            }
        }

        // List of Transactions
        if (filteredList.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Koi hisaab nahi mila!",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                            color = TextMuted
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Uper diye gaye buttons se naya kharcha ya raqam add karein.",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                    }
                }
            }
        } else {
            items(filteredList, key = { it.id }) { item ->
                TransactionRowItem(
                    item = item,
                    currencySymbol = currency,
                    onEdit = { onEditTransaction(item) },
                    onDelete = { onDeleteTransaction(item) },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp)
                )
            }
        }
    }
}
