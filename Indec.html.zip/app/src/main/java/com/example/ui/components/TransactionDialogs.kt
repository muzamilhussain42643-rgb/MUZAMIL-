package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.TransactionItem
import com.example.model.CategoryConstants
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.TextMuted
import com.example.viewmodel.MainViewModel

@Composable
fun AddEditExpenseDialog(
    initialItem: TransactionItem? = null,
    currencySymbol: String = "₨",
    onDismiss: () -> Unit,
    onSave: (amount: Double, category: String, title: String, date: String, paymentMode: String, note: String) -> Unit
) {
    var amountText by remember { mutableStateOf(initialItem?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: "") }
    var selectedCategory by remember { mutableStateOf(initialItem?.category ?: CategoryConstants.EXPENSE_CATEGORIES.first().id) }
    var title by remember { mutableStateOf(initialItem?.title ?: "") }
    var dateText by remember { mutableStateOf(initialItem?.date ?: MainViewModel.getTodayString()) }
    var paymentMode by remember { mutableStateOf(initialItem?.paymentMode ?: "Cash") }
    var note by remember { mutableStateOf(initialItem?.note ?: "") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("add_edit_expense_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = if (initialItem == null) "Rozana Kharcha Add Karein" else "Kharcha Edit Karein",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "روزانہ کا خرچہ درج کریں",
                            fontSize = 13.sp,
                            color = ExpenseRed,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Amount Field
                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it.filter { char -> char.isDigit() || char == '.' }
                        errorMessage = null
                    },
                    label = { Text("Raqam / Amount ($currencySymbol)") },
                    placeholder = { Text("Jaise: 1500") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("expense_amount_input"),
                    singleLine = true,
                    leadingIcon = {
                        Text(
                            text = currencySymbol,
                            fontWeight = FontWeight.Bold,
                            color = ExpenseRed,
                            fontSize = 18.sp,
                            modifier = Modifier.padding(start = 12.dp)
                        )
                    }
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Category Selection
                Text(
                    text = "Category Muntakhib Karein (کیٹیگری):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(CategoryConstants.EXPENSE_CATEGORIES) { cat ->
                        val isSelected = cat.id == selectedCategory
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCategory = cat.id },
                            label = { Text(cat.nameEn) },
                            leadingIcon = {
                                Icon(
                                    imageVector = cat.icon,
                                    contentDescription = cat.nameEn,
                                    tint = if (isSelected) Color.White else cat.color,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = cat.color,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("category_chip_${cat.id}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Title / Description
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Tafseel / Title (مثلاً آلو پیاز، راشن)") },
                    placeholder = { Text("Saman ya kharche ki tafseel") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("expense_title_input"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Date Field
                OutlinedTextField(
                    value = dateText,
                    onValueChange = { dateText = it },
                    label = { Text("Tareekh / Date (YYYY-MM-DD)") },
                    trailingIcon = {
                        Icon(imageVector = Icons.Default.CalendarMonth, contentDescription = "Date")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("expense_date_input"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Payment Mode Selection
                Text(
                    text = "Adaigi Ka Tareeqa (ادائیگی کا طریقہ):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    CategoryConstants.PAYMENT_MODES.forEach { mode ->
                        val isSel = paymentMode == mode
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { paymentMode = mode }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = mode,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Note
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Koi Izafi Note (اختیاری)") },
                    placeholder = { Text("Dukan ya bill receipt number...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("expense_note_input"),
                    maxLines = 2
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMessage ?: "",
                        color = ExpenseRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Button(
                        onClick = {
                            val amount = amountText.toDoubleOrNull()
                            if (amount == null || amount <= 0) {
                                errorMessage = "Durust raqam darj karein!"
                                return@Button
                            }
                            onSave(
                                amount,
                                selectedCategory,
                                title.trim(),
                                dateText.trim(),
                                paymentMode,
                                note.trim()
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed),
                        modifier = Modifier.testTag("save_expense_button")
                    ) {
                        Text(
                            text = if (initialItem == null) "Kharcha Save Karein" else "Update Karein",
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AddEditIncomeDialog(
    initialItem: TransactionItem? = null,
    currencySymbol: String = "₨",
    onDismiss: () -> Unit,
    onSave: (amount: Double, source: String, title: String, date: String, paymentMode: String, note: String) -> Unit
) {
    var amountText by remember { mutableStateOf(initialItem?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: "") }
    var selectedSource by remember { mutableStateOf(initialItem?.category ?: CategoryConstants.INCOME_CATEGORIES.first().id) }
    var title by remember { mutableStateOf(initialItem?.title ?: "") }
    var dateText by remember { mutableStateOf(initialItem?.date ?: MainViewModel.getTodayString()) }
    var paymentMode by remember { mutableStateOf(initialItem?.paymentMode ?: "Cash") }
    var note by remember { mutableStateOf(initialItem?.note ?: "") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("add_edit_income_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = if (initialItem == null) "Ghar Se Mile Paise" else "Raqam Edit Karein",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "گھر سے ملنے والی رقم کا اندراج",
                            fontSize = 13.sp,
                            color = IncomeGreen,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Amount Field
                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it.filter { char -> char.isDigit() || char == '.' }
                        errorMessage = null
                    },
                    label = { Text("Milne Wali Raqam ($currencySymbol)") },
                    placeholder = { Text("Jaise: 30000") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("income_amount_input"),
                    singleLine = true,
                    leadingIcon = {
                        Text(
                            text = currencySymbol,
                            fontWeight = FontWeight.Bold,
                            color = IncomeGreen,
                            fontSize = 18.sp,
                            modifier = Modifier.padding(start = 12.dp)
                        )
                    }
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Source Selection
                Text(
                    text = "Kahan Se Mile? (پیسے دینے والے کا ذریعہ):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(CategoryConstants.INCOME_CATEGORIES) { src ->
                        val isSelected = src.id == selectedSource
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedSource = src.id },
                            label = { Text(src.nameEn) },
                            leadingIcon = {
                                Icon(
                                    imageVector = src.icon,
                                    contentDescription = src.nameEn,
                                    tint = if (isSelected) Color.White else src.color,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = src.color,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("income_source_chip_${src.id}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Title
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Naam / Tafseel (مثلاً ابو نے خرچے کے لیے بھیجے)") },
                    placeholder = { Text("Ghar se mile paise ki waja") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("income_title_input"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Date Field
                OutlinedTextField(
                    value = dateText,
                    onValueChange = { dateText = it },
                    label = { Text("Tareekh / Date (YYYY-MM-DD)") },
                    trailingIcon = {
                        Icon(imageVector = Icons.Default.CalendarMonth, contentDescription = "Date")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("income_date_input"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Payment Mode Selection
                Text(
                    text = "Kese Receive Huay? (ذریعہ وصولی):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    CategoryConstants.PAYMENT_MODES.forEach { mode ->
                        val isSel = paymentMode == mode
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSel) IncomeGreen else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { paymentMode = mode }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = mode,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Note
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Izafi Note / Yad-dihani") },
                    placeholder = { Text("Kisi maqsad ke liye mile hon...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("income_note_input"),
                    maxLines = 2
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMessage ?: "",
                        color = ExpenseRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Button(
                        onClick = {
                            val amount = amountText.toDoubleOrNull()
                            if (amount == null || amount <= 0) {
                                errorMessage = "Durust raqam darj karein!"
                                return@Button
                            }
                            onSave(
                                amount,
                                selectedSource,
                                title.trim(),
                                dateText.trim(),
                                paymentMode,
                                note.trim()
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = IncomeGreen),
                        modifier = Modifier.testTag("save_income_button")
                    ) {
                        Text(
                            text = if (initialItem == null) "Raqam Save Karein" else "Update Karein",
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DeleteConfirmDialog(
    itemTitle: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Delete Ki Tasdeeq (حذف کریں)",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Text("Kya aap waqai '$itemTitle' ka record delete karna chahte hain? Ye wapas nahi aayega.")
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed),
                modifier = Modifier.testTag("confirm_delete_button")
            ) {
                Text("Haan, Delete Karein")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
