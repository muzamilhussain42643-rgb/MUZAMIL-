package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF0F5132)
val EmeraldDark = Color(0xFF0A3622)
val EmeraldLight = Color(0xFF198754)
val EmeraldContainer = Color(0xFFD1E7DD)
val OnEmeraldContainer = Color(0xFF0F5132)

val AmberGold = Color(0xFFD97706)
val AmberLight = Color(0xFFFEF3C7)

val ExpenseRed = Color(0xFFDC2626)
val ExpenseRedSoft = Color(0xFFFEE2E2)

val IncomeGreen = Color(0xFF16A34A)
val IncomeGreenSoft = Color(0xFFDCFCE7)

val BalanceBlue = Color(0xFF2563EB)
val BalanceBlueSoft = Color(0xFFDBEAFE)

val DarkSurface = Color(0xFF121820)
val DarkBackground = Color(0xFF0A0F14)
val DarkCard = Color(0xFF1B2430)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightCardBorder = Color(0xFFE2E8F0)
val TextMuted = Color(0xFF64748B)
