package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.TransactionItem
import com.example.ui.components.AddEditExpenseDialog
import com.example.ui.components.AddEditIncomeDialog
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.DailyKharchaScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.GharSeMilePaiseScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainApp()
            }
        }
    }
}

@Composable
fun MainApp(viewModel: MainViewModel = viewModel()) {
    val activeUser by viewModel.activeUser.collectAsStateWithLifecycle()
    val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val uiMessage by viewModel.uiMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    // Dialog visibility states
    var showAddExpenseDialog by remember { mutableStateOf(false) }
    var showAddIncomeDialog by remember { mutableStateOf(false) }
    var itemToEdit by remember { mutableStateOf<TransactionItem?>(null) }
    var itemToDelete by remember { mutableStateOf<TransactionItem?>(null) }

    // Navigation tab state: 0: Dashboard, 1: Daily Kharcha, 2: Ghar Se Mile, 3: Reports, 4: Account
    var currentTab by remember { mutableIntStateOf(0) }

    // Force auth screen display if requested or no active user
    var showAuthScreenExplicitly by remember { mutableStateOf(false) }

    // Snackbar notifications
    LaunchedEffect(uiMessage) {
        uiMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg, duration = SnackbarDuration.Short)
            viewModel.clearUiMessage()
        }
    }

    // Back handling
    if (currentTab != 0) {
        BackHandler {
            currentTab = 0
        }
    }

    if (activeUser == null || showAuthScreenExplicitly) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            contentWindowInsets = WindowInsets.safeDrawing
        ) { paddingValues ->
            AuthScreen(
                onLogin = { email, pass ->
                    viewModel.login(email, pass) {
                        showAuthScreenExplicitly = false
                    }
                },
                onRegister = { name, house, email, pass, curr, budget ->
                    viewModel.register(name, house, email, pass, curr, budget) {
                        showAuthScreenExplicitly = false
                    }
                },
                onQuickDemoLogin = {
                    val demo = allUsers.firstOrNull()
                    if (demo != null) {
                        viewModel.switchUser(demo.id)
                        showAuthScreenExplicitly = false
                    } else {
                        viewModel.showMessage("Pehle naya account register karein!")
                    }
                },
                modifier = Modifier.padding(paddingValues)
            )
        }
    } else {
        val user = activeUser!!

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                NavigationBar(
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    NavigationBarItem(
                        selected = currentTab == 0,
                        onClick = { currentTab = 0 },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("Home", fontSize = 11.sp) },
                        modifier = Modifier.testTag("nav_home")
                    )
                    NavigationBarItem(
                        selected = currentTab == 1,
                        onClick = { currentTab = 1 },
                        icon = { Icon(Icons.Default.ShoppingCart, contentDescription = "Daily Kharcha") },
                        label = { Text("Kharcha", fontSize = 11.sp) },
                        modifier = Modifier.testTag("nav_daily_kharcha")
                    )
                    NavigationBarItem(
                        selected = currentTab == 2,
                        onClick = { currentTab = 2 },
                        icon = { Icon(Icons.Default.VolunteerActivism, contentDescription = "Ghar Se Mile") },
                        label = { Text("Ghar Se", fontSize = 11.sp) },
                        modifier = Modifier.testTag("nav_ghar_se_mile")
                    )
                    NavigationBarItem(
                        selected = currentTab == 3,
                        onClick = { currentTab = 3 },
                        icon = { Icon(Icons.Default.Assessment, contentDescription = "Reports") },
                        label = { Text("Reports", fontSize = 11.sp) },
                        modifier = Modifier.testTag("nav_reports")
                    )
                    NavigationBarItem(
                        selected = currentTab == 4,
                        onClick = { currentTab = 4 },
                        icon = { Icon(Icons.Default.AccountCircle, contentDescription = "Account") },
                        label = { Text("Account", fontSize = 11.sp) },
                        modifier = Modifier.testTag("nav_account")
                    )
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when (currentTab) {
                    0 -> DashboardScreen(
                        user = user,
                        transactions = transactions,
                        onAddExpense = { showAddExpenseDialog = true },
                        onAddIncome = { showAddIncomeDialog = true },
                        onViewReports = { currentTab = 3 },
                        onEditTransaction = { item -> itemToEdit = item },
                        onDeleteTransaction = { item -> itemToDelete = item }
                    )
                    1 -> DailyKharchaScreen(
                        user = user,
                        transactions = transactions,
                        onAddExpense = { showAddExpenseDialog = true },
                        onEditExpense = { item -> itemToEdit = item },
                        onDeleteExpense = { item -> itemToDelete = item }
                    )
                    2 -> GharSeMilePaiseScreen(
                        user = user,
                        transactions = transactions,
                        onAddIncome = { showAddIncomeDialog = true },
                        onEditIncome = { item -> itemToEdit = item },
                        onDeleteIncome = { item -> itemToDelete = item }
                    )
                    3 -> ReportsScreen(
                        user = user,
                        transactions = transactions
                    )
                    4 -> ProfileScreen(
                        user = user,
                        allUsers = allUsers,
                        onSwitchUser = { id -> viewModel.switchUser(id) },
                        onLogout = { viewModel.logout() },
                        onUpdateProfile = { updated -> viewModel.updateProfile(updated) },
                        onNavigateToRegister = { showAuthScreenExplicitly = true }
                    )
                }
            }
        }

        // Add Expense Dialog
        if (showAddExpenseDialog) {
            AddEditExpenseDialog(
                currencySymbol = user.currencySymbol,
                onDismiss = { showAddExpenseDialog = false },
                onSave = { amount, category, title, date, paymentMode, note ->
                    viewModel.addExpense(amount, category, title, date, paymentMode, note)
                    showAddExpenseDialog = false
                }
            )
        }

        // Add Income Dialog (Ghar Se Mile Paise)
        if (showAddIncomeDialog) {
            AddEditIncomeDialog(
                currencySymbol = user.currencySymbol,
                onDismiss = { showAddIncomeDialog = false },
                onSave = { amount, source, title, date, paymentMode, note ->
                    viewModel.addIncome(amount, source, title, date, paymentMode, note)
                    showAddIncomeDialog = false
                }
            )
        }

        // Edit Transaction Dialog (Detect whether it was Expense or Income)
        itemToEdit?.let { item ->
            if (item.type == "EXPENSE") {
                AddEditExpenseDialog(
                    initialItem = item,
                    currencySymbol = user.currencySymbol,
                    onDismiss = { itemToEdit = null },
                    onSave = { amount, category, title, date, paymentMode, note ->
                        viewModel.updateExpense(
                            item.copy(
                                amount = amount,
                                category = category,
                                title = title,
                                date = date,
                                paymentMode = paymentMode,
                                note = note
                            )
                        )
                        itemToEdit = null
                    }
                )
            } else {
                AddEditIncomeDialog(
                    initialItem = item,
                    currencySymbol = user.currencySymbol,
                    onDismiss = { itemToEdit = null },
                    onSave = { amount, source, title, date, paymentMode, note ->
                        viewModel.updateIncome(
                            item.copy(
                                amount = amount,
                                category = source,
                                title = title,
                                date = date,
                                paymentMode = paymentMode,
                                note = note
                            )
                        )
                        itemToEdit = null
                    }
                )
            }
        }

        // Delete Confirm Dialog
        itemToDelete?.let { item ->
            DeleteConfirmDialog(
                itemTitle = item.title,
                onConfirm = {
                    viewModel.deleteTransaction(item)
                    itemToDelete = null
                },
                onDismiss = { itemToDelete = null }
            )
        }
    }
}
