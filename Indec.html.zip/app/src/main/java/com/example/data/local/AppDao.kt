package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // User Profiles
    @Query("SELECT * FROM user_profiles ORDER BY id ASC")
    fun getAllUsers(): Flow<List<UserProfile>>

    @Query("SELECT * FROM user_profiles WHERE isActive = 1 LIMIT 1")
    fun getActiveUser(): Flow<UserProfile?>

    @Query("SELECT * FROM user_profiles WHERE id = :userId LIMIT 1")
    suspend fun getUserById(userId: Int): UserProfile?

    @Query("SELECT * FROM user_profiles WHERE emailOrPhone = :emailOrPhone LIMIT 1")
    suspend fun getUserByEmailOrPhone(emailOrPhone: String): UserProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserProfile): Long

    @Update
    suspend fun updateUser(user: UserProfile)

    @Query("UPDATE user_profiles SET isActive = 0")
    suspend fun deactivateAllUsers()

    @Query("UPDATE user_profiles SET isActive = 1 WHERE id = :userId")
    suspend fun setActiveUser(userId: Int)

    // Transactions (Both EXPENSE and INCOME)
    @Query("SELECT * FROM transactions WHERE userId = :userId ORDER BY timestamp DESC")
    fun getAllTransactions(userId: Int): Flow<List<TransactionItem>>

    @Query("SELECT * FROM transactions WHERE userId = :userId AND type = 'EXPENSE' ORDER BY timestamp DESC")
    fun getExpenses(userId: Int): Flow<List<TransactionItem>>

    @Query("SELECT * FROM transactions WHERE userId = :userId AND type = 'INCOME' ORDER BY timestamp DESC")
    fun getIncomes(userId: Int): Flow<List<TransactionItem>>

    @Query("SELECT * FROM transactions WHERE userId = :userId AND date = :date ORDER BY timestamp DESC")
    fun getTransactionsByDate(userId: Int, date: String): Flow<List<TransactionItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(transactions: List<TransactionItem>)

    @Update
    suspend fun updateTransaction(transaction: TransactionItem)

    @Delete
    suspend fun deleteTransaction(transaction: TransactionItem)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteTransactionById(id: Long)

    @Query("SELECT COUNT(*) FROM user_profiles")
    suspend fun getUserCount(): Int

    @Query("SELECT COUNT(*) FROM transactions")
    suspend fun getTransactionCount(): Int
}
