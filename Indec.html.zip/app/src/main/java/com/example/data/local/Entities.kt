package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profiles")
data class UserProfile(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val fullName: String,
    val houseName: String,
    val emailOrPhone: String,
    val passwordHash: String,
    val currencySymbol: String = "₨",
    val monthlyBudgetTarget: Double = 60000.0,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "transactions")
data class TransactionItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Int = 1,
    val type: String, // "EXPENSE" or "INCOME"
    val amount: Double,
    val category: String,
    val title: String,
    val date: String, // YYYY-MM-DD
    val timestamp: Long = System.currentTimeMillis(),
    val paymentMode: String = "Cash", // "Cash", "Bank Transfer", "EasyPaisa", "JazzCash"
    val note: String = ""
)
