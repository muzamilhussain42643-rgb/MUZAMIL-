package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Database(
    entities = [UserProfile::class, TransactionItem::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ghar_kharcha_database"
                )
                    .addCallback(AppDatabaseCallback(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database.appDao())
                }
            }
        }
    }
}

suspend fun populateInitialData(dao: AppDao) {
    if (dao.getUserCount() == 0) {
        val initialUser = UserProfile(
            id = 1,
            fullName = "Muzamil Khan",
            houseName = "Khan House (خان ہاؤس)",
            emailOrPhone = "muzamilkhang906@gmail.com",
            passwordHash = "1234",
            currencySymbol = "₨",
            monthlyBudgetTarget = 70000.0,
            isActive = true,
            createdAt = System.currentTimeMillis()
        )
        dao.insertUser(initialUser)

        val cal = Calendar.getInstance()
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

        val transactions = mutableListOf<TransactionItem>()

        // Current Month (e.g. October 2026) Income & Expenses
        // Today
        val todayStr = sdf.format(cal.time)
        val todayMillis = cal.timeInMillis

        // Yesterday
        cal.add(Calendar.DAY_OF_YEAR, -1)
        val yestStr = sdf.format(cal.time)
        val yestMillis = cal.timeInMillis

        // 2 days ago
        cal.add(Calendar.DAY_OF_YEAR, -1)
        val day2Str = sdf.format(cal.time)
        val day2Millis = cal.timeInMillis

        // 4 days ago
        cal.add(Calendar.DAY_OF_YEAR, -2)
        val day4Str = sdf.format(cal.time)
        val day4Millis = cal.timeInMillis

        // 7 days ago
        cal.add(Calendar.DAY_OF_YEAR, -3)
        val day7Str = sdf.format(cal.time)
        val day7Millis = cal.timeInMillis

        // 10 days ago (beginning of month)
        cal.add(Calendar.DAY_OF_YEAR, -3)
        val startMonthStr = sdf.format(cal.time)
        val startMonthMillis = cal.timeInMillis

        // --- Ghar Se Mile Paise (Income) for this month ---
        transactions.add(
            TransactionItem(
                userId = 1,
                type = "INCOME",
                amount = 40000.0,
                category = "Abba Jaan",
                title = "Ghar Ka Mahana Kharcha (Abba se mile)",
                date = startMonthStr,
                timestamp = startMonthMillis + 3600000,
                paymentMode = "Bank Transfer",
                note = "Mahine ke shuru me rashan aur bills ke liye mile"
            )
        )
        transactions.add(
            TransactionItem(
                userId = 1,
                type = "INCOME",
                amount = 15000.0,
                category = "Bhai / Sister",
                title = "Bade Bhai Ne Bheje (Pocket & Extras)",
                date = day7Str,
                timestamp = day7Millis + 7200000,
                paymentMode = "EasyPaisa",
                note = "Ghar ke zaroori kamo ke liye"
            )
        )
        transactions.add(
            TransactionItem(
                userId = 1,
                type = "INCOME",
                amount = 12000.0,
                category = "Ghar Ka Monthly Budget",
                title = "Ammi Ki Taraf Se Kharch",
                date = day4Str,
                timestamp = day4Millis + 1800000,
                paymentMode = "Cash",
                note = "Rozmarra ki sabzi aur doodh ke liye"
            )
        )

        // --- Daily Kharcha (Expenses) for this month ---
        transactions.add(
            TransactionItem(
                userId = 1,
                type = "EXPENSE",
                amount = 14500.0,
                category = "Rashan (Groceries)",
                title = "Aata, Chawal, Ghee, Daal & Masalay",
                date = startMonthStr,
                timestamp = startMonthMillis + 7200000,
                paymentMode = "Cash",
                note = "Super store se mahine ka ahem rashan"
            )
        )
        transactions.add(
            TransactionItem(
                userId = 1,
                type = "EXPENSE",
                amount = 8200.0,
                category = "Bijli & Gas Bills",
                title = "Bijli Aur Sui Gas Ka Bill",
                date = day7Str,
                timestamp = day7Millis + 10800000,
                paymentMode = "JazzCash",
                note = "WAPDA bijli bill clear kiya"
            )
        )
        transactions.add(
            TransactionItem(
                userId = 1,
                type = "EXPENSE",
                amount = 1850.0,
                category = "Sabzi & Fruit",
                title = "Taaza Sabzi Aur Phal (Fruits)",
                date = day4Str,
                timestamp = day4Millis + 14400000,
                paymentMode = "Cash",
                note = "Haftawar sabzi mandi kharidari"
            )
        )
        transactions.add(
            TransactionItem(
                userId = 1,
                type = "EXPENSE",
                amount = 3500.0,
                category = "Petrol & Safar",
                title = "Bike & Gari Ka Petrol",
                date = day2Str,
                timestamp = day2Millis + 18000000,
                paymentMode = "Cash",
                note = "Fuel tank fill up for weekly commute"
            )
        )
        transactions.add(
            TransactionItem(
                userId = 1,
                type = "EXPENSE",
                amount = 900.0,
                category = "Doodh (Milk)",
                title = "Khula Doodh (3 Din Ka Hisab)",
                date = yestStr,
                timestamp = yestMillis + 21600000,
                paymentMode = "Cash",
                note = "Dairy shop se khareeda"
            )
        )
        transactions.add(
            TransactionItem(
                userId = 1,
                type = "EXPENSE",
                amount = 650.0,
                category = "Chai & Khana",
                title = "Subha Ka Nashta Aur Bakery Saman",
                date = todayStr,
                timestamp = todayMillis - 14400000,
                paymentMode = "Cash",
                note = "Anday, double roti aur chai patti"
            )
        )
        transactions.add(
            TransactionItem(
                userId = 1,
                type = "EXPENSE",
                amount = 1200.0,
                category = "Dawa & Doctor",
                title = "Ghar Ki Zaroori Dawayian",
                date = todayStr,
                timestamp = todayMillis - 7200000,
                paymentMode = "EasyPaisa",
                note = "Medical store pharmacy se medicine"
            )
        )

        // Previous months data for rich Monthly & Yearly Reports
        val pastCalendar = Calendar.getInstance()
        // Last month (September 2026)
        pastCalendar.add(Calendar.MONTH, -1)
        val lastMonthIncomeDate = String.format(Locale.getDefault(), "%04d-%02d-05", pastCalendar.get(Calendar.YEAR), pastCalendar.get(Calendar.MONTH) + 1)
        val lastMonthExp1 = String.format(Locale.getDefault(), "%04d-%02d-08", pastCalendar.get(Calendar.YEAR), pastCalendar.get(Calendar.MONTH) + 1)
        val lastMonthExp2 = String.format(Locale.getDefault(), "%04d-%02d-15", pastCalendar.get(Calendar.YEAR), pastCalendar.get(Calendar.MONTH) + 1)

        transactions.add(
            TransactionItem(
                userId = 1,
                type = "INCOME",
                amount = 65000.0,
                category = "Ghar Ka Monthly Budget",
                title = "Pichle Mahine Ka Ghar Budget",
                date = lastMonthIncomeDate,
                timestamp = pastCalendar.timeInMillis,
                paymentMode = "Bank Transfer",
                note = "Monthly complete allowance"
            )
        )
        transactions.add(
            TransactionItem(
                userId = 1,
                type = "EXPENSE",
                amount = 22000.0,
                category = "Rashan (Groceries)",
                title = "Pichle Mahine Ka Rashan",
                date = lastMonthExp1,
                timestamp = pastCalendar.timeInMillis + 86400000,
                paymentMode = "Cash",
                note = "Monthly ration"
            )
        )
        transactions.add(
            TransactionItem(
                userId = 1,
                type = "EXPENSE",
                amount = 19500.0,
                category = "Bijli & Gas Bills",
                title = "Bills & Utility Payment",
                date = lastMonthExp2,
                timestamp = pastCalendar.timeInMillis + (86400000 * 7),
                paymentMode = "Bank Transfer",
                note = "Summer bills"
            )
        )

        dao.insertTransactions(transactions)
    }
}
