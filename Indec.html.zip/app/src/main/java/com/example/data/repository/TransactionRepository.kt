package com.example.data.repository

import com.example.data.local.AppDao
import com.example.data.local.TransactionItem
import com.example.data.local.UserProfile
import kotlinx.coroutines.flow.Flow

class TransactionRepository(private val dao: AppDao) {
    val allUsers: Flow<List<UserProfile>> = dao.getAllUsers()
    val activeUser: Flow<UserProfile?> = dao.getActiveUser()

    fun getAllTransactions(userId: Int): Flow<List<TransactionItem>> =
        dao.getAllTransactions(userId)

    fun getExpenses(userId: Int): Flow<List<TransactionItem>> =
        dao.getExpenses(userId)

    fun getIncomes(userId: Int): Flow<List<TransactionItem>> =
        dao.getIncomes(userId)

    fun getTransactionsByDate(userId: Int, date: String): Flow<List<TransactionItem>> =
        dao.getTransactionsByDate(userId, date)

    suspend fun insertTransaction(item: TransactionItem): Long =
        dao.insertTransaction(item)

    suspend fun updateTransaction(item: TransactionItem) =
        dao.updateTransaction(item)

    suspend fun deleteTransaction(item: TransactionItem) =
        dao.deleteTransaction(item)

    suspend fun deleteTransactionById(id: Long) =
        dao.deleteTransactionById(id)

    suspend fun registerUser(
        fullName: String,
        houseName: String,
        emailOrPhone: String,
        password: String,
        currencySymbol: String,
        monthlyTarget: Double
    ): Result<UserProfile> {
        val existing = dao.getUserByEmailOrPhone(emailOrPhone)
        if (existing != null) {
            return Result.failure(Exception("Ye account / email pehle se registered hai!"))
        }
        dao.deactivateAllUsers()
        val newUser = UserProfile(
            fullName = fullName,
            houseName = houseName,
            emailOrPhone = emailOrPhone,
            passwordHash = password,
            currencySymbol = currencySymbol,
            monthlyBudgetTarget = monthlyTarget,
            isActive = true
        )
        val id = dao.insertUser(newUser)
        return Result.success(newUser.copy(id = id.toInt()))
    }

    suspend fun loginUser(emailOrPhone: String, password: String): Result<UserProfile> {
        val user = dao.getUserByEmailOrPhone(emailOrPhone)
            ?: return Result.failure(Exception("Account nahi mila! Please check email/phone."))
        if (user.passwordHash != password) {
            return Result.failure(Exception("Ghalat password! Barah-e-karam dobara koshish karein."))
        }
        dao.deactivateAllUsers()
        dao.setActiveUser(user.id)
        return Result.success(user.copy(isActive = true))
    }

    suspend fun switchActiveUser(userId: Int) {
        dao.deactivateAllUsers()
        dao.setActiveUser(userId)
    }

    suspend fun updateProfile(user: UserProfile) {
        dao.updateUser(user)
    }

    suspend fun logout() {
        dao.deactivateAllUsers()
    }
}
